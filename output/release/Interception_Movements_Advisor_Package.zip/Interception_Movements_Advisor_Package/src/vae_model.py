"""Conditional trajectory autoencoders with optional timing inputs and outputs.

The final strategy study uses 100 x 2 position inputs, a five-element task
condition (start category, side and exact target speed), and separate position
and log-timing decoder heads. Physical timing is WITHHELD from its encoder via
``encoder_uses_timing=False``. The class retains timing-input support for older
experiments, so saved checkpoint settings, not defaults, define a run.

Conditioning makes task metadata available to the decoder; it does not ensure
that latent coordinates contain only intrinsic style or have causal semantics.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import config


# ── Condition encoding ────────────────────────────────────────────────────────
def encode_condition(sp: int, side: int) -> np.ndarray:
    """
    Create a condition vector from trial metadata.

    sp  : starting position index (1, 2, 3)
    side: starting side (1=left, 2=right)

    Returns a 4-dim vector: [one-hot sp (3)] + [side binary (1)]

    Start config and target speed
    -----------------------------
    ``sp`` indexes *both* the stimulus starting position
    (``config.STARTING_POSITIONS``: 120/140/160 mm) and the target speed range
    (``config.SPEED_RANGES``: 255-300 / 298-350 / 340-400 mm/s). They are
    confounded by the experimental design — the filename carries one index for
    the pair — so the one-hot over sp *is* the joint (start config, target
    speed) encoding. Adding separate start-position and speed columns would be
    exactly collinear with this one-hot and buy nothing.

    The exact speed within each range is not recoverable from filenames.
    The final loader recovers it from MAT/target metadata and
    ``encode_trial_condition`` appends it as a fifth continuous coordinate.

    This vector is concatenated into the encoder input *and* the decoder input
    (see ``ConditionalVAE.encode`` / ``.decode``). This makes the task available
    explicitly but does not guarantee separation of task and person effects.
    """
    vec = np.zeros(4, dtype=np.float32)
    if 1 <= sp <= 3:
        vec[sp - 1] = 1.0
    vec[3] = 1.0 if side == 2 else 0.0
    return vec


CONDITION_DIM = 4  # length of condition vector
TIMING_DIM = config.TIMING_DIM  # movement_time_s, initiation_time_s
TIMING_EPS = 1e-3


def encode_trial_condition(metadata: dict, condition_dim: int | None = None) -> np.ndarray:
    """Encode task condition, adding exact target speed when it is available."""
    base = encode_condition(int(metadata.get("sp", 1)), int(metadata.get("side", 1)))
    speed = metadata.get("target_speed_screen_s")
    has_speed = speed is not None and np.isfinite(float(speed))
    if condition_dim is None:
        condition_dim = CONDITION_DIM + int(has_speed)
    if condition_dim == CONDITION_DIM:
        return base
    if condition_dim == CONDITION_DIM + 1:
        if not has_speed:
            # Nominal center of each observed target-speed band, used only for
            # controlled traversals where no particular recorded trial exists.
            speed = {1: 0.545, 2: 0.635, 3: 0.725}.get(int(metadata.get("sp", 2)), 0.635)
        return np.r_[base, np.float32(speed)].astype(np.float32)
    raise ValueError(f"unsupported condition width: {condition_dim}")


def transform_timing(timing, transform: str = "log"):
    """Map nonnegative seconds to the space optimized by the timing head."""
    if transform == "identity":
        return timing
    if transform == "log":
        if torch.is_tensor(timing):
            return torch.log(torch.clamp(timing, min=0) + TIMING_EPS)
        return np.log(np.maximum(np.asarray(timing), 0) + TIMING_EPS)
    raise ValueError(f"unknown timing transform: {transform}")


def inverse_timing(timing, transform: str = "log"):
    """Map timing-head output back to nonnegative seconds."""
    if transform == "identity":
        return timing
    if transform == "log":
        if torch.is_tensor(timing):
            return torch.clamp(torch.exp(timing) - TIMING_EPS, min=0)
        return np.maximum(np.exp(np.asarray(timing)) - TIMING_EPS, 0)
    raise ValueError(f"unknown timing transform: {transform}")


def encode_timing(trial: dict, fs: float = config.RECORDING_HZ) -> np.ndarray:
    """
    Extract the timing channels (in seconds) from a preprocessed trial.

    Derived from the raw-frame indices rather than stored separately, so trial
    dicts cached before the timing head existed still work.

        movement_time_s   : movement onset → finger arrival (movement duration)
        initiation_time_s : go-signal → movement onset (reaction / wait time)

    Reaction time is measured from the **go-signal** (``go_signal_idx``, the
    moment the object starts moving), not from object appearance, so the
    randomised foreperiod does not contaminate it. Falls back to the stimulus
    marker for trial dicts built before the go-signal was tracked.
    """
    ref = trial.get("go_signal_idx", trial["stim_onset_idx"])
    move_time = (trial["move_end_idx"] - trial["move_start_idx"]) / fs
    init_time = (trial["move_start_idx"] - ref) / fs
    return np.array([move_time, init_time], dtype=np.float32)


# ── VAE Model ─────────────────────────────────────────────────────────────────
class ConditionalVAE(nn.Module):
    """Conditional VAE for trajectory reconstruction with a timing head."""

    def __init__(
        self,
        input_dim: int = config.NORMALISED_LENGTH * 3,
        condition_dim: int = CONDITION_DIM,
        hidden_dim: int = config.HIDDEN_DIM,
        latent_dim: int = config.DEFAULT_LATENT_DIM,
        timing_dim: int = TIMING_DIM,
        encoder_uses_timing: bool = True,
        variational: bool = True,
        use_condition: bool = True,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.condition_dim = condition_dim
        self.latent_dim = latent_dim
        self.timing_dim = timing_dim
        self.encoder_uses_timing = encoder_uses_timing
        self.variational = variational
        self.use_condition = use_condition

        # Encoder — sees the trajectory, its timing, and the task condition
        enc_input = input_dim + (timing_dim if encoder_uses_timing else 0) + condition_dim
        self.encoder = nn.Sequential(
            nn.Linear(enc_input, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)

        # Decoder — shared trunk, one head per output modality
        dec_input = latent_dim + condition_dim
        self.decoder = nn.Sequential(
            nn.Linear(dec_input, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.traj_head = nn.Linear(hidden_dim, input_dim)
        self.timing_head = nn.Linear(hidden_dim, timing_dim) if timing_dim else None

    def encode(
        self,
        x: torch.Tensor,
        c: torch.Tensor,
        timing: torch.Tensor | None = None,
    ):
        parts = [x]
        if self.timing_dim and self.encoder_uses_timing:
            if timing is None:
                raise ValueError(
                    f"model has timing_dim={self.timing_dim}; encode() needs a timing tensor"
                )
            parts.append(timing)
        parts.append(c if self.use_condition else torch.zeros_like(c))
        h = self.encoder(torch.cat(parts, dim=-1))
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h) if self.variational else torch.full_like(mu, -30.0)
        return mu, logvar

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        if not self.variational:
            return mu
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z: torch.Tensor, c: torch.Tensor):
        """Returns (trajectory, timing); timing is None when timing_dim == 0."""
        condition = c if self.use_condition else torch.zeros_like(c)
        h = self.decoder(torch.cat([z, condition], dim=-1))
        timing = self.timing_head(h) if self.timing_head is not None else None
        return self.traj_head(h), timing

    def forward(
        self,
        x: torch.Tensor,
        c: torch.Tensor,
        timing: torch.Tensor | None = None,
    ):
        """Returns (recon_traj, recon_timing, mu, logvar, z)."""
        mu, logvar = self.encode(x, c, timing)
        z = self.reparameterize(mu, logvar)
        recon, recon_timing = self.decode(z, c)
        return recon, recon_timing, mu, logvar, z


# ── Convolutional variant ────────────────────────────────────────────────────
class ConvCVAE(nn.Module):
    """
    1-D convolutional Conditional VAE — a drop-in alternative to ``ConditionalVAE``
    with the same ``encode`` / ``decode`` / ``forward`` interface.

    Where the MLP treats the 300 trajectory numbers as an unordered bag, this
    reads the trajectory as a 3-channel (x, y, z) signal of length 100 and slides
    convolutions along time, so it respects frame order and shares weights across
    the movement. Kept selectable (config.ARCHITECTURE) so the MLP stays the
    default and both can be compared.
    """

    def __init__(
        self,
        input_dim: int = config.NORMALISED_LENGTH * 3,
        condition_dim: int = CONDITION_DIM,
        hidden_dim: int = config.HIDDEN_DIM,
        latent_dim: int = config.DEFAULT_LATENT_DIM,
        timing_dim: int = TIMING_DIM,
        encoder_uses_timing: bool = True,
        seq_len: int = config.NORMALISED_LENGTH,
        channels: int = 3,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.latent_dim = latent_dim
        self.timing_dim = timing_dim
        self.encoder_uses_timing = encoder_uses_timing
        self.seq_len = seq_len
        self.channels = channels
        self.enc_len = 13  # 100 -> 50 -> 25 -> 13 under three stride-2 convs
        flat = 128 * self.enc_len

        self.enc_conv = nn.Sequential(
            nn.Conv1d(channels, 32, 5, stride=2, padding=2), nn.ReLU(),
            nn.Conv1d(32, 64, 5, stride=2, padding=2), nn.ReLU(),
            nn.Conv1d(64, 128, 5, stride=2, padding=2), nn.ReLU(),
        )
        self.enc_fc = nn.Sequential(
            nn.Linear(flat + (timing_dim if encoder_uses_timing else 0) + condition_dim, hidden_dim), nn.ReLU()
        )
        self.fc_mu = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)

        self.dec_fc = nn.Sequential(
            nn.Linear(latent_dim + condition_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, flat), nn.ReLU(),
        )
        self.dec_conv = nn.Sequential(
            nn.ConvTranspose1d(128, 64, 5, stride=2, padding=2, output_padding=0), nn.ReLU(),
            nn.ConvTranspose1d(64, 32, 5, stride=2, padding=2, output_padding=1), nn.ReLU(),
            nn.ConvTranspose1d(32, channels, 5, stride=2, padding=2, output_padding=1),
        )
        self.timing_head = (
            nn.Sequential(nn.Linear(latent_dim + condition_dim, hidden_dim), nn.ReLU(),
                          nn.Linear(hidden_dim, timing_dim))
            if timing_dim else None
        )

    def encode(self, x, c, timing=None):
        b = x.size(0)
        xt = x.view(b, self.seq_len, self.channels).permute(0, 2, 1)  # (b, 3, 100)
        h = self.enc_conv(xt).reshape(b, -1)
        parts = [h]
        if self.timing_dim and self.encoder_uses_timing:
            if timing is None:
                raise ValueError("ConvCVAE has timing_dim>0; encode() needs a timing tensor")
            parts.append(timing)
        parts.append(c)
        h = self.enc_fc(torch.cat(parts, dim=-1))
        return self.fc_mu(h), self.fc_logvar(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + torch.randn_like(std) * std

    def decode(self, z, c):
        b = z.size(0)
        h = self.dec_fc(torch.cat([z, c], dim=-1)).view(b, 128, self.enc_len)
        xt = self.dec_conv(h)                                   # (b, 3, 100)
        traj = xt.permute(0, 2, 1).reshape(b, self.input_dim)   # (b, 300)
        timing = self.timing_head(torch.cat([z, c], dim=-1)) if self.timing_head is not None else None
        return traj, timing

    def forward(self, x, c, timing=None):
        mu, logvar = self.encode(x, c, timing)
        z = self.reparameterize(mu, logvar)
        recon, recon_timing = self.decode(z, c)
        return recon, recon_timing, mu, logvar, z


# ── KL annealing ──────────────────────────────────────────────────────────────
def kl_weight_at(
    epoch: int,
    target: float = config.KL_WEIGHT,
    schedule: str = config.KL_ANNEAL,
    anneal_epochs: int = config.KL_ANNEAL_EPOCHS,
    cycles: int = config.KL_ANNEAL_CYCLES,
    ratio: float = config.KL_ANNEAL_RATIO,
) -> float:
    """
    β for a given 1-indexed epoch.

    Annealing exists to avoid posterior collapse: at full β from the start, the
    cheapest way to cut the KL term is to make q(z|x) equal the prior and ignore
    z, and a decoder that has learned to work without the latent gets no
    gradient pulling it back. Ramping β from 0 lets reconstruction establish a
    use for the latent first.

    See ``config.KL_ANNEAL`` for the schedules.
    """
    if schedule == "none":
        return target
    if anneal_epochs <= 0:
        return target

    e = max(epoch - 1, 0)  # epochs are 1-indexed

    if schedule == "linear":
        return target * min(1.0, e / anneal_epochs)

    if schedule == "cyclical":
        # Each cycle ramps over `ratio` of its length, then holds at full β.
        cycle_len = max(anneal_epochs, 1)
        pos = (e % cycle_len) / cycle_len
        if cycles > 0 and e >= cycle_len * cycles:
            return target  # past the last cycle, stay at the true objective
        return target * min(1.0, pos / ratio) if ratio > 0 else target

    raise ValueError(f"unknown KL schedule: {schedule!r}")


# ── Loss function ─────────────────────────────────────────────────────────────
def vae_loss(
    recon: torch.Tensor,
    target: torch.Tensor,
    mu: torch.Tensor,
    logvar: torch.Tensor,
    kl_weight: float = config.KL_WEIGHT,
    recon_timing: torch.Tensor | None = None,
    target_timing: torch.Tensor | None = None,
    timing_weight: float = config.TIMING_WEIGHT,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    VAE ELBO loss = trajectory MSE + λ · timing MSE + β · KL divergence.

    Each term is summed over its dimensions and averaged over the batch.
    Therefore ``timing_weight`` is a per-scalar multiplier: 150 gives two
    timing scalars the same aggregate weight as 300 trajectory coordinates.

    Returns (total_loss, recon_loss, kl_loss, timing_loss).

    Reduction
    ---------
    Every term is **summed over its own dimensions and averaged over the
    batch** — the standard ELBO. This matters more than it looks: averaging the
    reconstruction over 300 trajectory dims while averaging the KL over
    ``latent_dim`` dims silently inflates the effective β by
    ``input_dim / latent_dim`` (100x at z=3), which crushes the latent and
    caps reconstruction quality regardless of how long the model trains.
    """
    recon_loss = F.mse_loss(recon, target, reduction="none").sum(dim=-1).mean()
    kl_loss = (-0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=-1)).mean()

    if recon_timing is not None and target_timing is not None:
        timing_loss = (
            F.mse_loss(recon_timing, target_timing, reduction="none").sum(dim=-1).mean()
        )
    else:
        timing_loss = torch.zeros((), device=recon.device, dtype=recon.dtype)

    total = recon_loss + timing_weight * timing_loss + kl_weight * kl_loss
    return total, recon_loss, kl_loss, timing_loss


# ── Normalisation statistics ──────────────────────────────────────────────────
@dataclass
class NormStats:
    """
    Train-set standardisation constants, kept together so trajectory and timing
    stats cannot drift apart between training, evaluation and the dashboard.
    """

    train_mean: np.ndarray
    train_std: np.ndarray
    timing_mean: np.ndarray
    timing_std: np.ndarray
    timing_transform: str = "identity"

    @classmethod
    def from_checkpoint(cls, ckpt: dict) -> "NormStats":
        """Read the stats out of a checkpoint dict saved by ``train_vae``."""
        as_arr = lambda v: np.asarray(v, dtype=np.float32)
        # Checkpoints written before the timing head lack the timing stats;
        # identity constants keep them loadable (they also have timing_dim=0).
        return cls(
            train_mean=as_arr(ckpt["train_mean"]),
            train_std=as_arr(ckpt["train_std"]),
            timing_mean=as_arr(ckpt.get("timing_mean", np.zeros(TIMING_DIM))),
            timing_std=as_arr(ckpt.get("timing_std", np.ones(TIMING_DIM))),
            timing_transform=ckpt.get("timing_transform", "identity"),
        )

    def torch(self, device: str = "cpu"):
        """Return the four constants as tensors on *device*."""
        t = lambda v: torch.as_tensor(v, dtype=torch.float32, device=device)
        return t(self.train_mean), t(self.train_std), t(self.timing_mean), t(self.timing_std)

    def denormalise_timing(self, timing_z: np.ndarray) -> np.ndarray:
        """Map standardised timing predictions back to seconds."""
        transformed = np.asarray(timing_z) * self.timing_std + self.timing_mean
        return inverse_timing(transformed, self.timing_transform)


# ── Dataset ───────────────────────────────────────────────────────────────────
class TrajectoryDataset(torch.utils.data.Dataset):
    """PyTorch dataset wrapping preprocessed trials."""

    def __init__(self, trials: list[dict]):
        self.trajectories = []
        self.timings = []
        self.conditions = []
        self.subjects = []
        self.trial_ids = []

        for t in trials:
            traj = t["pos_norm"].flatten().astype(np.float32)
            meta = t["metadata"]
            cond = encode_trial_condition(meta)
            self.trajectories.append(traj)
            self.timings.append(encode_timing(t))
            self.conditions.append(cond)
            self.subjects.append(meta.get("subject", ""))
            self.trial_ids.append(meta.get("trial_id", ""))

        self.trajectories = np.stack(self.trajectories)
        self.timings = np.stack(self.timings)
        self.conditions = np.stack(self.conditions)

    def __len__(self):
        return len(self.trajectories)

    def __getitem__(self, idx):
        return (
            torch.from_numpy(self.trajectories[idx]),
            torch.from_numpy(self.timings[idx]),
            torch.from_numpy(self.conditions[idx]),
            idx,
        )
